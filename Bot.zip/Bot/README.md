# Weekly Dictator Economy Bot
### Using Quick.db & Discord.js (V11)

##### sup idk what to put here so hi
